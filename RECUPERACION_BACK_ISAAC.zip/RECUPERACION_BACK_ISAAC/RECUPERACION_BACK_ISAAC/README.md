# API de usuarios (Node.js + Express + MongoDB + Cloudinary)

## Instalación
```bash
npm install
cp .env.example .env   # y completa tus credenciales
npm run dev
```

## Endpoints (`/api/usuarios`)
| Método | Ruta | Descripción |
|---|---|---|
| POST | `/registro` | form-data: nombre, apellido, email, password, telefono, fechaNacimiento, **fotoPerfil** (archivo) |
| POST | `/verificar` | JSON: `{ "email", "codigo" }` |
| POST | `/reenviar-codigo` | JSON: `{ "email" }` |
| GET | `/` | Listar |
| GET | `/:id` | Ver uno |
| PUT | `/:id` | form-data, campos opcionales (+ `fotoPerfil` reemplaza la imagen en Cloudinary) |
| DELETE | `/:id` | Elimina usuario y su foto de Cloudinary |

## Evidencia en Postman
Importa `postman_collection.json`. Orden sugerido:
1. Registro exitoso → copia el `id` de la respuesta a la variable `userId`.
2. Verificar con código incorrecto → luego con el código recibido por correo.
3. Probar validaciones (duplicado, email, contraseña, sin foto).
4. CRUD y cambio/eliminación de foto (revisa Cloudinary en cada paso).
