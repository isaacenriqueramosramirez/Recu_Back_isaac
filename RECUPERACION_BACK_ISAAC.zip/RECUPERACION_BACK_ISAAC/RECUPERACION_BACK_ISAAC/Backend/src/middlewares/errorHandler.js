const multer = require('multer');

module.exports = (err, req, res, next) => {
  if (err instanceof multer.MulterError) {
    const msg = err.code === 'LIMIT_FILE_SIZE'
      ? 'La imagen supera el tamaño máximo de 5 MB'
      : `Error al subir archivo: ${err.message}`;
    return res.status(400).json({ ok: false, mensaje: msg });
  }
  if (err.code === 11000) {
    return res.status(409).json({ ok: false, mensaje: 'El correo ya está registrado' });
  }
  if (err.name === 'ValidationError') {
    return res.status(400).json({
      ok: false,
      mensaje: 'Datos inválidos',
      errores: Object.values(err.errors).map((e) => e.message),
    });
  }
  if (err.name === 'CastError') {
    return res.status(400).json({ ok: false, mensaje: 'ID inválido' });
  }
  const status = err.status || 500;
  if (status === 500) console.error(err);
  res.status(status).json({
    ok: false,
    mensaje: status === 500 ? 'Error interno del servidor' : err.message,
    ...(err.errores && { errores: err.errores }),
  });
};
