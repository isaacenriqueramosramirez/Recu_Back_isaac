const nodemailer = require('nodemailer');

const transporter = nodemailer.createTransport({
  host: process.env.MAIL_HOST,
  port: Number(process.env.MAIL_PORT) || 587,
  secure: false,
  auth: { user: process.env.MAIL_USER, pass: process.env.MAIL_PASS },
});

const enviarCodigo = (email, nombre, codigo) =>
  transporter.sendMail({
    from: `"Verificación" <${process.env.MAIL_USER}>`,
    to: email,
    subject: 'Tu código de verificación',
    html: `<p>Hola ${nombre},</p>
           <p>Tu código de verificación es: <b style="font-size:22px">${codigo}</b></p>
           <p>Vence en ${process.env.CODE_EXPIRES_MIN || 10} minutos.</p>`,
  });

module.exports = { enviarCodigo };
