const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/;
const PASS_RE = /^(?=.*[A-Za-z])(?=.*\d).{8,}$/;

// Devuelve lista de errores. `parcial` = true para PUT (solo valida lo enviado)
const validarUsuario = (b, { parcial = false } = {}) => {
  const errores = [];
  const req = ['nombre', 'apellido', 'email', 'password', 'telefono', 'fechaNacimiento'];

  if (!parcial) {
    req.forEach((c) => {
      if (!b[c] || !String(b[c]).trim()) errores.push(`El campo '${c}' es obligatorio`);
    });
  }
  if (b.email !== undefined && b.email && !EMAIL_RE.test(b.email))
    errores.push('El formato del correo no es válido');
  if (b.password !== undefined && b.password && !PASS_RE.test(b.password))
    errores.push('La contraseña debe tener mínimo 8 caracteres, con letras y números');
  if (b.fechaNacimiento) {
    const f = new Date(b.fechaNacimiento);
    if (isNaN(f) || f > new Date()) errores.push('La fecha de nacimiento no es válida');
  }
  if (b.telefono && !/^\+?\d{7,15}$/.test(String(b.telefono).replace(/[\s-]/g, '')))
    errores.push('El teléfono debe tener entre 7 y 15 dígitos');
  return errores;
};

module.exports = { validarUsuario, EMAIL_RE };
