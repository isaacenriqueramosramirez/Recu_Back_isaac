class AppError extends Error {
  constructor(message, status = 400, errores) {
    super(message);
    this.status = status;
    this.errores = errores;
  }
}
module.exports = AppError;
